from .llm import LLMInterface
from .paper_structure import Author, Reference, Figure, PaperSection, ResearchPaper
